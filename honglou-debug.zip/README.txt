Honglou debug source package

Verified dependency relationships
- article-honglou.html contains its CSS inline in <style> blocks.
- article-honglou.html contains its JavaScript inline in its <script> block.
- No local CSS or JavaScript src/href dependency is referenced by this page.
- No runtime fetch/import of a separate Markdown, JSON, or data file was found. The page embeds HONGLOU_SOURCE and RESPOND_SOURCE in its inline script.
- Image and video paths remain referenced by the page but are intentionally not included in this package, per request.

Previous narrow-column repair recorded in the current HTML
- The page wrapper uses class="layout toc-integrated".
- .layout.toc-integrated sets a centered single-column reading area (width:min(1000px,92vw); grid-template-columns:minmax(0,1fr)).
- .layout.toc-integrated .index is hidden so the former permanent index does not reserve a narrow column.
- The mobile rule sets that wrapper to width:calc(100% - 48px) below 900px.
- render() hides the old #index and applies toc-integrated; the TOC drawer remains an overlay and does not reserve reading width.
